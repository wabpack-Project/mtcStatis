var servicePageNum = 1 //当前页码
var serviceShowCount = 10 //当前显示页数
var totalData // 服务注册所有数据
var showData = [] //当前页数据
var postData = {} //发送数据
// 获取列表数据
function getServiceData () {
	$.ajax({
		url: '',
		type: 'post',
		success: function (msg) {
			var data = msg.rows
			if (data.length) {
				totalData = msg
				getServicePageData(data)
			} else {
				$('.service-table table tbody').empty()
				$('.service-table .list-page').hide().siblings('.noData').show()
			}
		},
		error: function (err) {
			console.log(err)
		}
	})
}

// 设置服务数据开关
function setServiceOpen (data) {
	$.ajax({
		url: '',
		type: 'post',
		data: data,
		success: function (msg) {
			
			// TODO 判断成功和失败，给出相应提示
		},
		error: function (err) {
			console.log(err)
		}
	})
}

// 获取分页列表数据
function getServicePageData (data) {
	$(".service-table .list-page").paging({
		pageNum: servicePageNum,
		totalNum: Math.ceil(totalData.total / Page.showCount),
		totalList: totalData.total,
		callback: function (num) {
			servicePageNum = num
			var listHtml = ''
			for (var i = (servicePageNum - 1) * serviceShowCount; i < servicePageNum * serviceShowCount; i++) {
				listHtml += '<tr id="'+ data[i].id +'"><td>' + data[i].serviceClassName + '</td><td>' + data[i].serviceName + '</td><td>' + data[i].serviceVersion + '</td><td>' + data[i].framework + '</td><td>' + data[i].registerTime
				listHtml += '</td><td>' + data[i].link + '</td><td>' + data[i].Status + '</td>\]<td>' + data[i].open + '</td><td>' + data[i].count 
				listHtml += '</td><td><a class="viewDetails" href="#">查看</a><a href="#">修改</a><a href="#">删除</a></td></tr>'
			}

			$('.service-table table tbody').html(listHtml)
		}
	})
	$('.service-table .list-page').show().siblings('.noData').hide()
}

$(function () {
	// getServiceData()
	
	$('body').on('click', '.service-table tbody .viewDetails', function () {
		// 查看服务数据详情
		$('.mask').show()
	});
	
	// Switchery.prototype.isChecked = true;
	// Switchery.prototype.setPosition(true);
	
	// var elem = document.querySelector('.js-switch');
	// Switchery(elem, {disabled: true});
	
	$(".switchery").click(function(){
		console.log(1);
	});
	
// switchery.enable();
	
	Switchery.prototype.handleOnchange = function(state) {
	  if (document.dispatchEvent) {
	    var event = document.createEvent('HTMLEvents');
	    event.initEvent('change', true, true);
	    this.element.dispatchEvent(event);
	  } else {
	    this.element.fireEvent('onchange');
	  }
	  
	  var postOpen = {};
	  	console.log(this.element.checked);
	   if (this.element.checked) {
	  	postOpen.open = 1; 
	    }else{
		  postOpen.open = 0;
	    }
		
		// id
		console.log(this.element);
		console.log($(this.element).parents("tr"));
		
		postOpen.id = $(this.element).parents("tr").attr("id");
		console.log(postOpen.id);
		console.log(postOpen);
		// setServiceOpen(postOpen);
	};
	
	
})